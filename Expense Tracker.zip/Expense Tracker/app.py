from flask import Flask, render_template, request, redirect, url_for
import sqlite3

app = Flask(__name__)

DATABASE = "expenses.db"


def get_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_db()

    conn.execute("""
        CREATE TABLE IF NOT EXISTS expenses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            amount REAL NOT NULL,
            category TEXT NOT NULL
        )
    """)

    conn.commit()
    conn.close()


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/add", methods=["POST"])
def add_expense():

    name = request.form.get("name", "").strip()
    amount = request.form.get("amount", "").strip()
    category = request.form.get("category", "").strip()

    # Validation
    if not name or not amount or not category:
        return render_template(
            "result.html",
            success=False,
            message="Please fill in all fields."
        )

    try:
        amount = float(amount)

        if amount <= 0:
            return render_template(
                "result.html",
                success=False,
                message="Amount must be greater than zero."
            )

    except ValueError:
        return render_template(
            "result.html",
            success=False,
            message="Please enter a valid numeric amount."
        )

    # Insert into database
    conn = get_db()

    conn.execute(
        """
        INSERT INTO expenses (name, amount, category)
        VALUES (?, ?, ?)
        """,
        (name, amount, category)
    )

    conn.commit()
    conn.close()

    return redirect(url_for("view_expenses"))


@app.route("/expenses")
def view_expenses():

    conn = get_db()

    expenses = conn.execute(
        "SELECT * FROM expenses ORDER BY id DESC"
    ).fetchall()

    conn.close()

    total = sum(expense["amount"] for expense in expenses)

    count = len(expenses)

    average = total / count if count > 0 else 0

    # Category totals
    category_totals = {}

    for expense in expenses:

        category = expense["category"]

        category_totals[category] = (
            category_totals.get(category, 0)
            + expense["amount"]
        )

    return render_template(
        "result.html",
        expenses=expenses,
        total=total,
        count=count,
        average=average,
        category_totals=category_totals,
        success=True
    )


@app.route("/delete/<int:expense_id>")
def delete_expense(expense_id):

    conn = get_db()

    conn.execute(
        "DELETE FROM expenses WHERE id = ?",
        (expense_id,)
    )

    conn.commit()
    conn.close()

    return redirect(url_for("view_expenses"))

@app.route("/edit/<int:expense_id>", methods=["GET", "POST"])
def edit_expense(expense_id):

    conn = get_db()

    expense = conn.execute(
        "SELECT * FROM expenses WHERE id = ?",
        (expense_id,)
    ).fetchone()

    if expense is None:
        conn.close()
        return "Expense not found", 404

    if request.method == "POST":

        name = request.form.get("name", "").strip()
        amount = request.form.get("amount", "").strip()
        category = request.form.get("category", "").strip()

        # Validation
        if not name or not amount or not category:

            conn.close()

            return render_template(
                "edit.html",
                expense=expense,
                error="Please fill in all fields."
            )

        try:
            amount = float(amount)

            if amount <= 0:

                conn.close()

                return render_template(
                    "edit.html",
                    expense=expense,
                    error="Amount must be greater than zero."
                )

        except ValueError:

            conn.close()

            return render_template(
                "edit.html",
                expense=expense,
                error="Please enter a valid numeric amount."
            )

        # Update database
        conn.execute(
            """
            UPDATE expenses
            SET name = ?, amount = ?, category = ?
            WHERE id = ?
            """,
            (name, amount, category, expense_id)
        )

        conn.commit()
        conn.close()

        return redirect(url_for("view_expenses"))

    conn.close()

    return render_template(
        "edit.html",
        expense=expense
    )

@app.route("/about")
def about():
    return render_template("about.html")


if __name__ == "__main__":

    init_db()

    app.run(debug=True)